﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MonacoTabs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserControl1 newTab = new UserControl1();
            string title = "Script: " + (tabControl1.TabCount + 1).ToString();
            TabPage tab = new TabPage();
            tab.Text = title.ToString();
            newTab.Dock = DockStyle.Fill;
            tab.Controls.Add(newTab);
            tabControl1.Controls.Add(tab);
            tabControl1.SelectTab(tabControl1.TabCount - 1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if(tabControl1.TabPages.Count > 0)
                {
                    WebBrowser webBrowser1 = this.tabControl1.SelectedTab.Controls.Find("webBrowser1", true).FirstOrDefault<Control>() as WebBrowser;
                    HtmlDocument document = webBrowser1.Document;
                    string scriptName = "GetText";
                    object[] args = new string[0];
                    object obj = document.InvokeScript(scriptName, args);
                    string script = obj.ToString();
                    MessageBox.Show(script);
                }

            }
            catch { }
                
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (tabControl1.TabPages.Count > 0)
                {
                    WebBrowser webBrowser1 = this.tabControl1.SelectedTab.Controls.Find("webBrowser1", true).FirstOrDefault<Control>() as WebBrowser;
                    webBrowser1.Document.InvokeScript("SetText", new object[]
                    {
                        "SetText"
                    });
                }
            }
            catch { }
        }
    }
}
